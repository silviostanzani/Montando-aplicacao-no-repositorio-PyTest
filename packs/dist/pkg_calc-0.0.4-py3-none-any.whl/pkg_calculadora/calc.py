def sum(a,b):
    res=a+b
    return(res)

def multi(a,b):
    res=a*b
    return(res)

def minus(a,b):
    res=a-b
    return(res)

def div(a,b):
    res=a/b
    return(res)
